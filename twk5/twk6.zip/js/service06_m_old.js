// =====================================================
// Service06 Page - Language + Theme handled by js/app_context.js
// =====================================================
// app_context.js applies language + theme globally once.
// Current settings are available via window.APP_CTX.

/*
 * ***********************************
 * ***********************************
 */
// Open Popup
    document.querySelectorAll('.select-trigger').forEach(trigger => {
        trigger.addEventListener('click', function() {
            const popupId = this.getAttribute('data-popup');
            if (popupId) {
                document.getElementById(popupId).classList.add('show');
            }
        });
    });

    // Close Popup
    function closePopup(popupId) {
        document.getElementById(popupId).classList.remove('show');
    }

    // Close popup when clicking outside
    document.querySelectorAll('.popup-overlay').forEach(overlay => {
        overlay.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('show');
            }
        });
    });

    function getI18nText(key, fallback) {
    // لو i18n.js عندك يوفر دالة ترجمة مباشرة (اختياري)
    if (window.I18N && typeof window.I18N.t === 'function') {
        const t = window.I18N.t(key);
        if (t) return t;
    }

    // الأفضل: نقرأ النص من العنصر الذي عليه data-i18n داخل الصفحة (بعد ما i18n يترجم)
    const el = document.querySelector(`[data-i18n="${key}"]`);
    if (el && el.textContent.trim()) return el.textContent.trim();

    return fallback || key;
    }

    function selectOption(popupId, inputId, i18nKey, value) {
    const trigger = document.querySelector(`[data-popup="${popupId}"]`);

    // النص حسب اللغة الحالية
    const displayText = getI18nText(i18nKey, '');

    trigger.innerHTML = `<span>${displayText}</span>`;
    trigger.classList.add('has-value');
    trigger.classList.remove('error');

    document.getElementById(inputId).value = value;

    closePopup(popupId);
    }

    // Select Document Type and Update Duration Options
    function selectDocumentType(i18nKey, value) {
    const trigger = document.querySelector('[data-popup="documentTypePopup"]');
    const displayText = getI18nText(i18nKey, '');

    trigger.innerHTML = `<span>${displayText}</span>`;
    trigger.classList.add('has-value');
    trigger.classList.remove('error');

    document.getElementById('documentTypeValue').value = value;

    updateDurationOptions(value);

    // مهم: لا تكتب "اختر مدة الوثيقة" كنص عربي ثابت
    const durationTrigger = document.getElementById('durationTrigger');
    const chooseDurationText = getI18nText('service06.choose_doc_duration', 'Choose document duration');
    durationTrigger.innerHTML = `<span data-i18n="service06.choose_doc_duration">${chooseDurationText}</span>`;
    durationTrigger.classList.remove('has-value');
    document.getElementById('documentDurationValue').value = '';

    closePopup('documentTypePopup');
    }


    // Update Duration Options
    function updateDurationOptions(documentType) {
        const durationBody = document.getElementById('durationPopupBody');

        let options = '';
        
        if (documentType === '34') {
            options = `
                <label class="option" onclick="selectOption('documentDurationPopup', 'documentDurationValue', 'ستة أشهر', '101')">
                    <input type="radio" name="documentDurationRadio" value="101">
                    <div class="option-content">
                        <span class="radio-circle"></span>
                        <span>ستة أشهر</span>
                    </div>
                </label>
            `;
        } else if (documentType === '35') {
            options = `
                <label class="option" onclick="selectOption('documentDurationPopup', 'documentDurationValue', 'سنة', '104')">
                    <input type="radio" name="documentDurationRadio" value="104">
                    <div class="option-content">
                        <span class="radio-circle"></span>
                        <span>سنة</span>
                    </div>
                </label>
                <label class="option" onclick="selectOption('documentDurationPopup', 'documentDurationValue', 'سنتين', '103')">
                    <input type="radio" name="documentDurationRadio" value="103">
                    <div class="option-content">
                        <span class="radio-circle"></span>
                        <span>سنتين</span>
                    </div>
                </label>
                <label class="option" onclick="selectOption('documentDurationPopup', 'documentDurationValue', 'ثلاث سنوات', '102')">
                    <input type="radio" name="documentDurationRadio" value="102">
                    <div class="option-content">
                        <span class="radio-circle"></span>
                        <span>ثلاث سنوات</span>
                    </div>
                </label>
            `;
        }
        
        durationBody.innerHTML = options;
    }


// Input Validations
const nationalIdInput = document.getElementById('nationalId');
nationalIdInput.addEventListener('input', function(e) {
    this.value = this.value.replace(/\D/g, '').slice(0, 10);
});


const mobileNumberInput = document.getElementById('mobileNumber');
if (mobileNumberInput) {
    mobileNumberInput.addEventListener('input', function(e) {
        // Only allow numbers
       //// this.value = this.value.replace(/\D/g, '');
        
        // Limit to 10 digits
        if (this.value.length > 13) {
            this.value = this.value.slice(0, 13);
        }
        
        // Must start with 05
        if (this.value.length >= 2 && !this.value.startsWith('+9665')) {
            this.value = '+9665';
        }
    });
}

// Postal code input filter (5 digits)
const postalCodeInput = document.getElementById('postalCode');
if (postalCodeInput) {
    postalCodeInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/\D/g, '').slice(0, 5);
    });
}

// Email input - trim spaces
const emailInput = document.getElementById('email');
if (emailInput) {
    emailInput.addEventListener('blur', function(e) {
        this.value = this.value.trim().toLowerCase();
    });
}

['buildingNumber', 'unitNumber', 'additionalCode','postalCode'].forEach(id => {
    const input = document.getElementById(id);
    if (input) {
        input.addEventListener('input', function(e) {
            this.value = this.value.replace(/\D/g, '');
        });
    }
});

// Form Validation
function validateForm() {
    let isValid = true;
    
    // Clear all errors
    document.querySelectorAll('.error-message').forEach(err => err.classList.remove('show'));
    document.querySelectorAll('.error').forEach(el => el.classList.remove('error'));

    // Service Type
    if (!document.getElementById('serviceTypeValue').value) {
        document.querySelector('[data-popup="serviceTypePopup"]').classList.add('error');
        document.querySelector('[data-error="serviceType"]').classList.add('show');
        isValid = false;
    }

    // Full Name
    const fullName = document.getElementById('fullName');
    if (!fullName.value.trim()) {
        fullName.classList.add('error');
        document.querySelector('[data-error="fullName"]').classList.add('show');
        isValid = false;
    }

    // National ID
    const nationalId = document.getElementById('nationalId');
    const nationalIdValue = nationalId.value;
    if (!nationalIdValue || nationalIdValue.length !== 10 || !['1', '2', '3'].includes(nationalIdValue[0])) {
        nationalId.classList.add('error');
        document.querySelector('[data-error="nationalId"]').classList.add('show');
        isValid = false;
    }

    // Birth Date
    /*   if (!birthDateValue.value) {
        dateInput.classList.add('error');
        document.querySelector('[data-error="birthDate"]').classList.add('show');
        isValid = false;
    }*/

    // City/District
    const cityDistrict = document.getElementById('cityDistrict');
    if (!cityDistrict.value.trim()) {
        cityDistrict.classList.add('error');
        document.querySelector('[data-error="cityDistrict"]').classList.add('show');
        isValid = false;
    }

    // Short Address
    const shortAddress = document.getElementById('shortAddress');
    if (!shortAddress.value.trim()) {
        shortAddress.classList.add('error');
        document.querySelector('[data-error="shortAddress"]').classList.add('show');
        isValid = false;
    }

    // Building Number
    const buildingNumber = document.getElementById('buildingNumber');
    if (!buildingNumber.value.trim() || buildingNumber.value.length > 4) {
        buildingNumber.classList.add('error');
        document.querySelector('[data-error="buildingNumber"]').classList.add('show');
        isValid = false;
    }

    // Unit Number
    const unitNumber = document.getElementById('unitNumber');
    if (!unitNumber.value.trim() || unitNumber.value.length > 3) {
        unitNumber.classList.add('error');
        document.querySelector('[data-error="unitNumber"]').classList.add('show');
        isValid = false;
    }

    // Additional Code
    const additionalCode = document.getElementById('additionalCode');
    if (!additionalCode.value.trim() || additionalCode.value.length > 4) {
        additionalCode.classList.add('error');
        document.querySelector('[data-error="additionalCode"]').classList.add('show');
        isValid = false;
    }

    // Postal Code
    const postalCode = document.getElementById('postalCode');
    if (!postalCode.value.trim() || postalCode.value.length > 5) {
        postalCode.classList.add('error');
        document.querySelector('[data-error="postalCode"]').classList.add('show');
        isValid = false;
    }

    // Document Type
    if (!document.getElementById('documentTypeValue').value) {
        document.querySelector('[data-popup="documentTypePopup"]').classList.add('error');
        document.querySelector('[data-error="documentType"]').classList.add('show');
        isValid = false;
    }

    // Document Duration
    if (!document.getElementById('documentDurationValue').value) {
        document.getElementById('durationTrigger').classList.add('error');
        document.querySelector('[data-error="documentDuration"]').classList.add('show');
        isValid = false;
    }

    // ========== نهاية دالة validateForm ==========
    return isValid;
}


// Next Button
document.getElementById('nextBtn').addEventListener('click', function(e) {
    e.preventDefault();
    
    if (validateForm()) {
        const data = {
            serviceType: document.getElementById('serviceTypeValue').value,
            fullName: document.getElementById('fullName').value,
            nationalId: document.getElementById('nationalId').value,
            birthDate: document.getElementById('birthDate').value, /*birthDateValue.value,*/
            cityDistrict: document.getElementById('cityDistrict').value,
            shortAddress: document.getElementById('shortAddress').value,
            postalCode: document.getElementById('postalCode').value,
            buildingNumber: document.getElementById('buildingNumber').value,
            unitNumber: document.getElementById('unitNumber').value,
            additionalCode: document.getElementById('additionalCode').value,
            documentType: document.getElementById('documentTypeValue').value,
            documentDuration: document.getElementById('documentDurationValue').value
        };
        
        console.log('Form Data:', data);
        alert('تم التحقق من البيانات بنجاح!\n\nسيتم الانتقال إلى صفحة المرفقات...');
    } else {
        const firstError = document.querySelector('.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
});

// Previous Button
document.querySelector('.btn-prev').addEventListener('click', function() {
   // alert('الرجوع إلى صفحة اتفاقية الاستخدام...');
    window.location.href = 'terms.html';
});

// Remove error on input
document.querySelectorAll('input[type="text"]').forEach(input => {
    input.addEventListener('input', function() {
        if (this.value.trim()) {
            this.classList.remove('error');
        }
    });
});



// عند الضغط على زر "متابعة"
document.getElementById('nextBtn').addEventListener('click', function(e) {
    e.preventDefault();
    
    if (validateForm()) {
        const data = {
            serviceType: document.getElementById('serviceTypeValue').value,
            fullName: document.getElementById('fullName').value,
            nationalId: document.getElementById('nationalId').value,
            birthDate: document.getElementById('birthDate').value, /*birthDateValue.value,*/
            cityDistrict: document.getElementById('cityDistrict').value,
            shortAddress: document.getElementById('shortAddress').value,
            postalCode: document.getElementById('postalCode').value,
            buildingNumber: document.getElementById('buildingNumber').value,
            unitNumber: document.getElementById('unitNumber').value,
            additionalCode: document.getElementById('additionalCode').value,
            documentType: document.getElementById('documentTypeValue').value,
            documentDuration: document.getElementById('documentDurationValue').value
        };
        
        // حفظ نوع الخدمة في localStorage
        localStorage.setItem('serviceType', data.serviceType);
        
        // حفظ جميع البيانات (اختياري)
        localStorage.setItem('formData', JSON.stringify(data));
        
        // الانتقال لصفحة المرفقات
        window.location.href = 'attachment.html';
    } else {
        const firstError = document.querySelector('.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
});
